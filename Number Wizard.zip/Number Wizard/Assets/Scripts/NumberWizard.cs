﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class NumberWizard : MonoBehaviour {
	int maximum;
	int minimum;
	int guess;

	// Use this for initialization
	void Start () {
		StartGame(); 
		maximum = maximum + 1;
		print ("Welcome to Number Wizard!");
		print ("Pick a number in your head, but don't tell me!");

		print ("The highest number you can pick is " + maximum);
		print ("The lowest number you can pick is " + minimum);

		print ("Is the number higher or lower than " + guess + "?"); 
		print ("Up arrow = higher, Down arrow = lower, and Enter = equal");
		}
		void StartGame ()
	{
		 maximum = 1000;
		 minimum = 1;
		 guess = 500;
		{
		maximum = maximum;

		print ("========================");
		print ("Welcome to Number Wizard!");
		print ("Pick a number in your head, but don't tell me!");

		print ("The highest number you can pick is " + maximum);
		print ("The lowest number you can pick is " + minimum);

		print ("Is the number higher or lower than " + guess + "?"); 
		print ("Up arrow = higher, Down arrow = lower, and Enter = equal");
			maximum = maximum;
		}
	}
	// Update is called once per frame
	void Update ()
	{
		 if (Input.GetKeyDown (KeyCode.UpArrow)) {
			minimum = guess; 
			NextGuess();

		} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
			maximum = guess; 
			NextGuess();

		} else if (Input.GetKeyDown (KeyCode.Return)) {
			print ("I won!");
			StartGame();
		}
	}
	void NextGuess () {
		guess = (maximum + minimum) / 2;
			print ("Higher or lower than " + guess);
			print ("Up arrow = higher, Down arrow = lower, and Enter = equal");
	}
}
